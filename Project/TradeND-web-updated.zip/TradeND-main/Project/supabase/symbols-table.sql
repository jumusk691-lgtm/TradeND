-- Run in Supabase SQL Editor after importing the Angel One master rows into this table.
-- The website queries this table directly; it does NOT download angel_master.db.
create table if not exists public.symbols (
  token text,
  symbol text,
  exch_seg text,
  strike text,
  expiry text,
  name text,
  lotsize text,
  tick_size text,
  instrumenttype text
);
create index if not exists symbols_symbol_idx on public.symbols (symbol);
create index if not exists symbols_name_idx on public.symbols (name);
create index if not exists symbols_exch_seg_idx on public.symbols (exch_seg);

-- Public read access for the browser's anon key. Do not grant browser write access.
alter table public.symbols enable row level security;
drop policy if exists "public can read symbols" on public.symbols;
create policy "public can read symbols" on public.symbols
  for select to anon, authenticated using (true);
