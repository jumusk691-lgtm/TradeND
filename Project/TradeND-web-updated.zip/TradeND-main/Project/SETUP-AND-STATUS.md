# TradeND web update — setup and important status

## Included in this update
- Firebase email/password sign-in and registration now use Firebase Authentication.
- New profiles are stored at `users_details/{Firebase UID}`; passwords are never written to Realtime Database.
- Watchlist, open positions, wallet balance and transaction history are synchronized to the user's Firebase UID path.
- Buy/Sell and Exit retain the existing website trade panel calculations and now sync positions/balance to Firebase.
- Deposit and withdrawal create PENDING requests. They do not create fake completed payments or automatically credit/debit funds.
- Symbol search now queries a Supabase Postgres table named `public.symbols`. The website no longer fetches the SQLite `angel_master.db` file.

## Required deployment configuration
1. Copy `.env.example` to `.env` (or set the same VITE_ variables in your hosting provider).
2. Fill Firebase Web App values from Firebase Console. The current project defaults are present in `src/lib/firebase.ts`, but environment variables are preferred.
3. Enable Email/Password in Firebase Authentication.
4. Fill `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` using the Supabase anon/public key only.
5. Create/import the Angel One symbol rows into Supabase Postgres table `public.symbols` with the columns in `supabase/symbols-table.sql`. Run that SQL in Supabase SQL Editor. The browser searches the table; a Storage `.db` file alone is not queryable as a Postgres table.
6. Configure the existing live-price WebSocket backend. The website currently references `wss://myt-backend-1.onrender.com/ws` in the TradePanel and WatchlistPanel. This project ZIP does not include that backend, so verify that it is running and supports the APK message format.

## Critical security / testing notes
- This is an internal simulated trading prototype, not a live exchange broker connection. Do not accept real deposits or withdrawals through these UI requests.
- The current browser-side Firebase balance/position writes are suitable only for controlled testing. They are NOT secure against a malicious client. Before public launch, move trade execution and wallet ledger mutations to a trusted backend/Cloud Function using Firebase Admin SDK, and apply strict RTDB rules so clients cannot write their own balance/positions.
- Existing legacy accounts stored under email-comma keys with plaintext passwords will not authenticate through Firebase Auth automatically. Migrate them securely using a trusted admin process; do not copy plaintext passwords into new profiles.
- Test registration, login, order placement, exit, and two-user data isolation in a non-production Firebase project before publishing.

## Build
From the `Project` folder run:
`npm ci`
`npm run build`

Deploy the generated `dist` folder to Vercel/Netlify or your hosting provider.
