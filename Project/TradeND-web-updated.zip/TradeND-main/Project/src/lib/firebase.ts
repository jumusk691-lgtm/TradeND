import { initializeApp, getApps } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getAuth } from 'firebase/auth';

// Public Firebase Web configuration. Restrict the API key in Google Cloud.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'AIzaSyD9JvroqZtwREJX51m6Jg_dRfYdvuuQHvU',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'trade-f600a.firebaseapp.com',
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || 'https://trade-f600a-default-rtdb.firebaseio.com',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'trade-f600a',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'trade-f600a.firebasestorage.app',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '322191828273',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:322191828273:web:f6d95229649c0b10013c10',
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const auth = getAuth(app);
