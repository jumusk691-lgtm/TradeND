import { useCallback, useEffect, useState } from 'react';
import { Splash } from '@/components/Splash';
import { Dashboard } from '@/components/Dashboard';
import { SupportModal } from '@/components/SupportModal';
import { Ticker } from '@/components/Ticker';
import { INSTRUMENTS } from '@/data/instruments';
import { usePersistentState } from '@/hooks/usePersistentState';
import { useLivePrices } from '@/hooks/useLivePrices';
import { makeTx } from '@/components/WalletPanel';
import type { DashboardTab, Position, WalletTx } from '@/types';

// Firebase imports for Realtime Database balance & watchlist sync
import { ref, onValue, set, update } from 'firebase/database';
import { db } from '@/lib/firebase';


const STARTING_BALANCE = 50000;

function App() {
  const [view, setView] = useState<'splash' | 'dashboard'>('splash');
  const [supportOpen, setSupportOpen] = useState(false);

  // Persistent client-side session state (localStorage fallback)
  const [walletBalance, setWalletBalance] = usePersistentState<number>(
    'tradend:wallet',
    STARTING_BALANCE
  );
  
  // Watchlist initialized as empty
  const [watchlist, setWatchlist] = usePersistentState<any[]>('tradend:watchlist', []);
  const [positions, setPositions] = usePersistentState<Position[]>('tradend:positions', []);
  const [transactions, setTransactions] = usePersistentState<WalletTx[]>(
    'tradend:txns',
    []
  );
  const [activeTab, setActiveTab] = usePersistentState<DashboardTab>(
    'tradend:tab',
    'markets'
  );

  // 🔥 1. FIREBASE REAL-TIME BALANCE LISTENER (Re-syncs dynamically on View change / Login)
  useEffect(() => {
    const currentUid = localStorage.getItem('tradend:uid');
    if (!currentUid) return;

    const balanceRef = ref(db, `users_details/${currentUid}/funds/balance`);

    const unsubscribe = onValue(
      balanceRef,
      (snapshot) => {
        const serverBalance = snapshot.val();
        if (serverBalance !== null && serverBalance !== undefined) {
          const parsedBal = Number(serverBalance);
          if (!isNaN(parsedBal)) {
            setWalletBalance(parsedBal);
          }
        }
      },
      (error) => {
        console.error("Firebase balance fetch error:", error);
      }
    );

    return () => unsubscribe();
  }, [view, setWalletBalance]);

  // 🔥 2. FIREBASE REAL-TIME WATCHLIST SYNC (User Isolation)
  useEffect(() => {
    const currentUid = localStorage.getItem('tradend:uid');
    if (!currentUid) return;

    const watchlistRef = ref(db, `users_details/${currentUid}/watchlist`);

    const unsubscribe = onValue(
      watchlistRef,
      (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const listArray = Array.isArray(data) ? data : Object.values(data);
          setWatchlist(listArray);
        } else {
          set(watchlistRef, []);
        }
      },
      (error) => {
        console.error("Firebase watchlist sync error:", error);
      }
    );

    return () => unsubscribe();
  }, [view, setWatchlist]);

  // Firebase real-time sync for positions and wallet transaction history.
  useEffect(() => {
    const uid = localStorage.getItem('tradend:uid');
    if (!uid) return;
    const positionsRef = ref(db, `users_details/${uid}/positions`);
    const txRef = ref(db, `users_details/${uid}/transactions`);
    const stopPositions = onValue(positionsRef, (snap) => {
      const value = snap.val();
      setPositions(value ? (Array.isArray(value) ? value : Object.values(value)) as Position[] : []);
    });
    const stopTx = onValue(txRef, (snap) => {
      const value = snap.val();
      setTransactions(value ? (Array.isArray(value) ? value : Object.values(value)) as WalletTx[] : []);
    });
    return () => { stopPositions(); stopTx(); };
  }, [view, setPositions, setTransactions]);

  // Live prices for the ticker
  const seeds: Record<string, number> = {};
  for (const i of INSTRUMENTS) seeds[i.symbol] = i.price;
  const livePrices = useLivePrices(seeds, 2200);

  // Lock body scroll while on splash
  useEffect(() => {
    if (view === 'splash') {
      document.body.classList.add('splash-locked');
    } else {
      document.body.classList.remove('splash-locked');
    }
    return () => document.body.classList.remove('splash-locked');
  }, [view]);

  // 🌟 3. SECURE HANDLE ENTER (Verifies active login UID before entering Dashboard)
  const handleEnter = useCallback(() => {
    const currentUid = localStorage.getItem('tradend:uid');
    if (currentUid) {
      setView('dashboard');
      requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: 'smooth' }));
    } else {
      console.warn("No active UID found. Sign in required.");
    }
  }, []);

  const handleBackToSplash = useCallback(() => {
    // Clear session on logout / back to splash
    localStorage.removeItem('tradend:uid');
    localStorage.removeItem('tradend:email');
    localStorage.removeItem('tradend:name');
    setView('splash');
    requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }, []);

  // --- Watchlist handlers (Synced directly to Firebase per user UID) ---
  const updateFirebaseWatchlist = useCallback((newList: any[]) => {
    setWatchlist(newList);
    const currentUid = localStorage.getItem('tradend:uid');
    if (!currentUid) return;

    const watchlistRef = ref(db, `users_details/${currentUid}/watchlist`);
    set(watchlistRef, newList).catch((err) => {
      console.error("Failed to update watchlist in Firebase:", err);
    });
  }, [setWatchlist]);

  const toggleWatch = useCallback(
    (contractOrSymbol: any) => {
      const isObj = typeof contractOrSymbol === 'object' && contractOrSymbol !== null;
      const targetSymbol = isObj ? contractOrSymbol.symbol : contractOrSymbol;

      const updatedList = (() => {
        const exists = watchlist.some((item) => 
          typeof item === 'string' ? item === targetSymbol : item?.symbol === targetSymbol
        );

        if (exists) {
          return watchlist.filter((item) => 
            typeof item === 'string' ? item !== targetSymbol : item?.symbol !== targetSymbol
          );
        } else {
          const newObj = isObj ? contractOrSymbol : {
            symbol: targetSymbol,
            name: targetSymbol,
            exchange: 'NSE',
            lotsize: 1
          };
          return [...watchlist, newObj];
        }
      })();

      updateFirebaseWatchlist(updatedList);
    },
    [watchlist, updateFirebaseWatchlist]
  );

  const removeWatch = useCallback(
    (symbolOrObject: any) => {
      const targetSymbol = typeof symbolOrObject === 'object' && symbolOrObject !== null 
        ? symbolOrObject.symbol 
        : symbolOrObject;

      const updatedList = watchlist.filter((item) => 
        typeof item === 'string' ? item !== targetSymbol : item?.symbol !== targetSymbol
      );

      updateFirebaseWatchlist(updatedList);
    },
    [watchlist, updateFirebaseWatchlist]
  );

  // --- Position handlers ---
  const openPosition = useCallback(
    (p: Position) => {
      const uid = localStorage.getItem('tradend:uid');
      const nextPositions = [...positions, p];
      const nextBalance = Math.max(0, walletBalance - p.margin);
      setPositions(nextPositions);
      setWalletBalance(nextBalance);
      if (uid) update(ref(db, `users_details/${uid}`), {
        positions: nextPositions, 'funds/balance': nextBalance,
      }).catch((error) => console.error('Trade sync failed:', error));
    },
    [positions, walletBalance, setPositions, setWalletBalance]
  );

  const closePosition = useCallback(
    (id: string) => {
      const pos = positions.find((item) => item.id === id);
      if (!pos) return;
      const current = livePrices[pos.symbol] ?? pos.currentPrice;
      const direction = pos.side === 'BUY' ? 1 : -1;
      const pnl = (current - pos.entryPrice) * pos.qty * direction;
      const nextPositions = positions.filter((item) => item.id !== id);
      const nextBalance = Math.max(0, walletBalance + pos.margin + pnl);
      setPositions(nextPositions);
      setWalletBalance(nextBalance);
      const uid = localStorage.getItem('tradend:uid');
      if (uid) update(ref(db, `users_details/${uid}`), {
        positions: nextPositions, 'funds/balance': nextBalance,
      }).catch((error) => console.error('Exit sync failed:', error));
    },
    [positions, walletBalance, setPositions, setWalletBalance, livePrices]
  );

  // --- Wallet handlers ---
  const handleDeposit = useCallback(
    (amount: number, method: string) => {
      // Deposits are requests only. Never credit simulated funds until an admin verifies payment.
      const tx = makeTx('DEPOSIT', amount, method, 'PENDING');
      const next = [tx, ...transactions];
      setTransactions(next);
      const uid = localStorage.getItem('tradend:uid');
      if (uid) set(ref(db, `users_details/${uid}/transactions`), next)
        .then(() => set(ref(db, `deposit_requests/${tx.id}`), { uid, ...tx }))
        .catch((error) => console.error('Deposit request sync failed:', error));
    },
    [transactions, setTransactions]
  );

  const handleWithdraw = useCallback(
    (amount: number, method: string) => {
      // Withdrawal remains pending for admin review; it does not alter balance here.
      const tx = makeTx('WITHDRAW', amount, method, 'PENDING');
      const next = [tx, ...transactions];
      setTransactions(next);
      const uid = localStorage.getItem('tradend:uid');
      if (uid) set(ref(db, `users_details/${uid}/transactions`), next)
        .then(() => set(ref(db, `withdraw_requests/${tx.id}`), { uid, ...tx }))
        .catch((error) => console.error('Withdrawal request sync failed:', error));
    },
    [transactions, setTransactions]
  );

  return (
    <>
      {view === 'splash' ? (
        <Splash onEnter={handleEnter} />
      ) : (
        <>
          <Ticker livePrices={livePrices} />
          <Dashboard
            activeTab={activeTab}
            onTabChange={setActiveTab}
            walletBalance={walletBalance}
            watchlist={watchlist}
            positions={positions}
            transactions={transactions}
            onToggleWatch={toggleWatch}
            onRemoveWatch={removeWatch}
            onOpenPosition={openPosition}
            onClosePosition={closePosition}
            onDeposit={handleDeposit}
            onWithdraw={handleWithdraw}
            onBackToSplash={handleBackToSplash}
            onOpenSupport={() => setSupportOpen(true)}
          />
        </>
      )}

      <SupportModal open={supportOpen} onClose={() => setSupportOpen(false)} />
    </>
  );
}

export default App;
